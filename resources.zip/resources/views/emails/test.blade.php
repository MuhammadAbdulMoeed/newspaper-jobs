Hello ,
You had subscribed 
<br>
New Job has been uploaded in {{$test}}