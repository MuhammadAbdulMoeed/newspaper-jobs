Hello ,
You had subscribed 
<br>
New Job has been uploaded in <?php echo e($test); ?>