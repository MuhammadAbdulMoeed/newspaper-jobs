<?php
$adsense = App\AdsenseCode::inRandomOrder()->first();
?>
<?php if(!empty($adsense)): ?>
<?php echo $adsense->code; ?>

<?php else: ?>
<img src="<?php echo e(asset('public/cv.jpg')); ?>" width="100%" height="200px">
<?php endif; ?>