
<?php $__env->startSection('content'); ?>
<div id=wrapper_total>
   <div id="navigate">
      <div id=social>
         <div id=s2s class="soc_lnk">
            <br/>
         </div>
         <script>
            function socialHide(){
            document.getElementsByClassName("soc_lnk")[0].style.display="none";
            }
         </script>
      </div>
      <div class="container">
      	<form method="POST">
      	<div class="row">
      		<div class="col-md-3">
      			<select class="form-control" id="newspaper" required="required">
      				<?php $__currentLoopData = $newspapers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      				<option value="<?php echo e($news->slug); ?>"><?php echo e($news->title); ?></option>
      				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      			</select>
      		</div>
      		<div class="col-md-3" id="date">
      			<input type="date" name="date" id="datepicker" class="form-control" required="required">
      		</div>
      		<div class="col-md-3">
      			<select class="form-control" id="job_type" required="required">
      				<option value="jobs">Pakistan Jobs</option>
                  <option value="tendars">Abroad Jobs</option>
                  <option value="admissions">Online Jobs</option>
      			</select>
      		</div>
      		<div class="col-md-3">
      			<input type="button" onclick="searchVal(this)" name="submit" value="submit" class="btn btn-primary">
      		</div>
      	</div>
      </form>
      </div>
      <div id=clear></div>
      <br/>
      <?php echo $__env->make('frontend.includes.adsense-banner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         <div id=clear></div>
         <br>
         <div id="featured_latest_job">
        
        <div id=clear></div>
        <?php echo $__env->make('frontend.includes.sevenintoninty', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <br/>
        <div id="job-table">
           <table class="table">
               <thead>
                  <tr>
                     <th colspan='2'>Title</th>
                     <th>City</th>
                     <th>Date</th>
                     <th>Apply</th>
                  </tr>
               </thead>
              <tbody>
                 <?php $__currentLoopData = $newspaper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <td><img src="<?php echo e(asset('/storage/app/'.$news->rel_logo)); ?>" width="50" height="50"> 
                    </td>
                    <td><a href="<?php echo e(url('detail_page/'.$news->id)); ?>"> <?php echo e($news->title); ?> </a>
                       <br> <a href="<?php echo e(url('company_add/'.$news->company_name)); ?>"><p style="font-size: 15px"><?php echo e($news->company_name); ?> </p> </a></td>
                    <td><a href="<?php echo e(url('city/'.$news->getCity->id)); ?>"><?php echo e($news->getCity->title); ?></a></td>
                    <td><a href="<?php echo e(url('apply_date/'.$news->created_at->toDateString())); ?>"><?php echo e($news->created_at->format('d-m-Y')); ?></a></td>
                    <?php if($news->created_by == "executive"): ?>
                    <td><a href="<?php echo e(url('apply_job/'.$news->id)); ?>">Apply Now</a></td>
                    <?php else: ?>
                    <td><a href="<?php echo e(url('detail_page/'.$news->id)); ?>">View Detail</a></td>
                    <?php endif; ?>
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
           </table>
           <br/>
           <div id=clear></div>
           <br/>
        </div>
     </div>

      <div id="newspaper" style="margin-top:5px;clear: right;">
         <div id=clear></div>
         <?php echo $__env->make('frontend.includes.sevenintoninty', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         <br/>
         
          <?php $__currentLoopData = $newspapers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newspaper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <a href="<?php echo e(url('newspaper/'.$newspaper->id)); ?>"><img alt="<?php echo e($newspaper->title); ?>" src="<?php echo e(asset('/storage/app/'.$newspaper->logo)); ?>"  /></a>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div id=govt_div2 style="margin-top:5px;clear:right;">
         
         <br/>
         <br/>
         
         </div>
         <br/>
         <br/>
         <br/><br/>
         
      </div>
      <div id=clear></div>
      <div id=clear></div>
      
   </div>
   <div id=clear></div>
   <br/>
</div>
<script type="text/javascript">
function searchVal(elem){

	var news = $('#newspaper').find(":selected").val();
	var type = $('#job_type').find(":selected").val();
	var date = new Date($('#datepicker').val());
      day = date.getDate();
      month = date.getMonth() + 1;
      year = date.getFullYear();
      var datee = [year, month, day].join('-')
   console.log(datee , news , type   , isNaN(day));
   if(!isNaN(day)){
	window.location = "<?php echo e(url('/search')); ?>"+"/"+news+"/"+type+"/"+datee
   }

}
</script>

	


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>