
<?php $__env->startSection('content'); ?>
<div id=wrapper_total>
   <div id="navigate">
      <div id=left-ad-social style="position: absolute; width: 125px; float: left; top: -95px; left: -125px; z-index: 1; clear: both;">
         <div id="s2s">
            <!--  <img src=http://islamictiming.com/img/ad.jpg width=125px />  -->
         </div>
      </div>
      <div class="container">
         <form method="POST">
         <div class="row">
            <div class="col-md-3">
               <select class="form-control" id="newspaper" required="required">
                  <?php $__currentLoopData = $newspapers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($news->slug); ?>"><?php echo e($news->title); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
            <div class="col-md-3" id="date">
               <input type="date" name="date" id="datepicker" class="form-control" required="required">
            </div>
            <div class="col-md-3">
               <select class="form-control" id="job_type" required="required">
                  <option value="jobs">Pakistan Jobs</option>
                  <option value="tendars">Abroad Jobs</option>
                  <option value="admissions">Online Jobs</option>
               </select>
            </div>
            <div class="col-md-3">
               <input type="button" onclick="searchVal(this)" name="submit" value="submit" class="btn btn-primary">
            </div>
         </div>
      </form>
      <br/>
       
      </div>
      <div id=clear></div>
      <div id="single-paper-page-banner">
         <?php echo $__env->make('frontend.includes.adsense-banner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         <h2 itemprop="name"><?php echo e($paper->title); ?></h2>
         <div id=clear></div>
          <a href="<?php echo e(url('user-scribe-news/'.$paper->id)); ?>">Subscribe</a>
      </div>
      <div id="featured_latest_job">
         <p><?php echo e($paper->title); ?> 
         <p style="font-size:1em; color:black; font-weight: 100;"><?php echo e($paper->title); ?></p>
         <div id=clear></div>
         <?php echo $__env->make('frontend.includes.sevenintoninty', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
         <?php
         $message = App\CustomMessagee::where('status' , '1')->where('newspaper_id' , $paper->id)->whereDate('date' , $date)->first();
         ?>
         <?php if($message == null): ?>
         <div id="job-table">
            <table class="table">
               <thead>
                  <tr>
                     <th>Title</th>
                     <th>City</th>
                     <th>Date</th>
                     <th>Apply Now</th>
                  </tr>
               </thead>
               <tbody>
                  <?php $__currentLoopData = $newspaper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><img src="<?php echo e(asset('/storage/app/'.$news->rel_logo)); ?>" width="50" height="50"> 
                     </td>
                     <td><a href="<?php echo e(url('detail_page/'.$news->id)); ?>"> <?php echo e($news->title); ?> </a></td>
                     <td><a href="<?php echo e(url('city/'.$news->getCity->id)); ?>"><?php echo e($news->getCity->title); ?></a></td>
<td><a href="<?php echo e(url('apply_date/'.$news->created_at->toDateString())); ?>"><?php echo e($news->created_at->format('d-m-Y')); ?></a></td>
                     <?php if($news->created_by == "executive"): ?>
                     <td><a href="<?php echo e(url('apply_job/'.$news->id)); ?>">Apply Now</a></td>
                     <?php else: ?>
                     <td><a href="<?php echo e(url('detail_page/'.$news->id)); ?>">View Detail</a></td>
                     <?php endif; ?>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
            <br/>
            <div id=clear></div>
            <br/>
         </div>
         <?php else: ?>
         <div class="alert alert-info">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
   <?php echo e($message->message); ?>

</div>
         <?php endif; ?>
      </div>
      <div id="newspaper" style="margin-top:5px;clear: right;">
         <div id=clear></div>
         <br/>
         
          <?php $__currentLoopData = $newspapers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newspaper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <a href="<?php echo e(url('newspaper/'.$newspaper->id)); ?>"><img alt="<?php echo e($newspaper->title); ?>" src="<?php echo e(asset('/storage/app/'.$newspaper->logo)); ?>"  /></a>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div id=govt_div2 style="margin-top:5px;clear:right;">
         
         <br/>
         <br/>
         
         </div>
         <br/>
         <br/>
      <div id=clear></div>
      <h3 color=#019875>About <?php echo e($paper->title); ?>:</h3>
      <p itemprop="description" color=#019875 style="font-size:1em;"><img itemprop="primaryImageOfPage" style="border-radius:0px;max-width:200px;width:80px;" align=left src="<?php echo e(asset('/storage/app/'.$paper->logo)); ?>"  /> <?php echo e($paper->description); ?>

      </p>
      <div id=clear></div>
   </div>
   <div id=clear></div>
   <br/>
</div>
<script type="text/javascript">
function searchVal(elem){

	var news = $('#newspaper').find(":selected").val();
	var type = $('#job_type').find(":selected").val();
	var date = new Date($('#datepicker').val());
      day = date.getDate();
      month = date.getMonth() + 1;
      year = date.getFullYear();
      var datee = [year, month, day].join('-')
   console.log(datee , news , type   , isNaN(day));
   if(!isNaN(day)){
	window.location = "<?php echo e(url('/search')); ?>"+"/"+news+"/"+type+"/"+datee
   }

}
</script>

	


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>