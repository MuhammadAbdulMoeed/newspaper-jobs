<?php
$adsense = App\AdsenseCode::where('size' , '300x600')->inRandomOrder()->first();
?>
<?php if(!empty($adsense)): ?>
<?php echo $adsense->code; ?>

<?php else: ?>
<img src="<?php echo e(asset('img/download.jpg')); ?>" style="width: 300px; height: 600px;"></tr>
<?php endif; ?>