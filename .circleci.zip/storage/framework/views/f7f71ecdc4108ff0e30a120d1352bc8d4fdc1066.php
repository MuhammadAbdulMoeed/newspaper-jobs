<?php
$adsense = App\AdsenseCode::where('size' , '348x340')->inRandomOrder()->first();
?>
<?php if(!empty($adsense)): ?>
<?php echo $adsense->code; ?>

<?php else: ?>
<img src="<?php echo e(asset('img/download.jpg')); ?>" style="width: 348px; height: 340px;"></tr>
<?php endif; ?>