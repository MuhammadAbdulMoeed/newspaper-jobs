

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center align-items-center mb-3">
        <div class="col col-sm-10 align-self-center">
            <div class="card">
                <div class="card-header">
                    <strong>
                        <?php echo e(app('translator')->getFromJson('navs.frontend.user.account')); ?>
                    </strong>
                </div>

                <div class="card-body">
                    <div role="tabpanel">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a href="#profile" class="nav-link active" aria-controls="profile" role="tab" data-toggle="tab"><?php echo e(app('translator')->getFromJson('navs.frontend.user.profile')); ?></a>
                            </li>

                            <li class="nav-item">
                                <a href="#edit" class="nav-link" aria-controls="edit" role="tab" data-toggle="tab"><?php echo e(app('translator')->getFromJson('labels.frontend.user.profile.update_information')); ?></a>
                            </li>

                            <li class="nav-item">
                                <a href="#cv" class="nav-link" aria-controls="edit" role="tab" data-toggle="tab">Upload CV</a>
                            </li>

                            <?php if($logged_in_user->canChangePassword()): ?>
                                <li class="nav-item">
                                    <a href="#password" class="nav-link" aria-controls="password" role="tab" data-toggle="tab"><?php echo e(app('translator')->getFromJson('navs.frontend.user.change_password')); ?></a>
                                </li>
                            <?php endif; ?>
                             <?php if($logged_in_user->canChangePassword()): ?>
                                <li class="nav-item">
                                    <a href="#detail" class="nav-link" aria-controls="password" role="tab" data-toggle="tab">Add Detail</a>
                                </li>
                                <li class="nav-item">
                                    <a href="#spec" class="nav-link" aria-controls="password" role="tab" data-toggle="tab">Add Speciality</a>
                                </li>
                            <?php endif; ?>
                        </ul>

                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane fade show active pt-3" id="profile" aria-labelledby="profile-tab">
                                <?php echo $__env->make('frontend.user.account.tabs.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div><!--tab panel profile-->

                            <div role="tabpanel" class="tab-pane fade show pt-3" id="edit" aria-labelledby="edit-tab">
                                <?php echo $__env->make('frontend.user.account.tabs.edit', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div><!--tab panel profile-->

                             <div role="tabpanel" class="tab-pane fade show pt-3" id="cv" aria-labelledby="edit-tab">
                                <div class="table-responsive">
                                    <form method="POST" action="<?php echo e(url('upload/user/cv')); ?>" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                    <table class="table table-striped table-hover table-bordered">
                                    <tr>
                                    <th>Upload CV</th>
                                    <td><input type="file" name="file"></td>
                                    </tr>
                                    </table>
                                    <input type="submit" name="submit" class="btn btn-default">
                                    </form>
                                </div>

                            </div>

                            <div role="tabpanel" class="tab-pane fade show pt-3" id="detail" aria-labelledby="edit-tab">
                                <div class="table-responsive">
                                    <form method="POST" action="<?php echo e(url('upload/user/detail')); ?>" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                    <table class="table table-striped table-hover table-bordered">
                                    <tr>
                                    <th>Gendar</th>
                                    <td><input type="text" name="gendar" value="<?php echo e($logged_in_user->gendar); ?>"></td>
                                    </tr>
                                    <tr>
                                    <th>Institute</th>
                                    <td><input type="text" name="institute" value="<?php echo e($logged_in_user->institution_one); ?>"></td>
                                    </tr>
                                    <tr>
                                    <th>Degree Title</th>
                                    <td><input type="text" name="degree_title" value="<?php echo e($logged_in_user->degree_title_two); ?>"></td>
                                    </tr>
                                    <tr>
                                    <th>Passing Year</th>
                                    <td><input type="text" name="passing_year" value="<?php echo e($logged_in_user->passing_year_two); ?>"></td>
                                    </tr>
                                    </table>
                                    <input type="submit" name="submit" class="btn btn-default">
                                    </form>
                                </div>

                            </div>

                            <div role="tabpanel" class="tab-pane fade show pt-3" id="spec" aria-labelledby="edit-tab">
                                <div class="table-responsive">
                                    <form method="POST" action="<?php echo e(url('upload/user/speciality')); ?>" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                    <select name="categories[]" multiple="multiple">
                                        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cat->id); ?>" <?php if(auth()->user()->findExplo($cat->id)): ?> selected <?php endif; ?> ><?php echo e($cat->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <input type="submit" name="submit" class="btn btn-primary">
                                    </form>
                                </div>

                            </div>

                            <?php if($logged_in_user->canChangePassword()): ?>
                                <div role="tabpanel" class="tab-pane fade show pt-3" id="password" aria-labelledby="password-tab">
                                    <?php echo $__env->make('frontend.user.account.tabs.change-password', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div><!--tab panel change password-->
                            <?php endif; ?>
                        </div><!--tab content-->
                    </div><!--tab panel-->
                </div><!--card body-->
            </div><!-- card -->
        </div><!-- col-xs-12 -->
    </div><!-- row -->
     <div class="row justify-content-center align-items-center mb-3">
        <div class="col col-sm-10 align-self-center">
            <div class="card">
                <div class="card-header">
                    <strong>
                        Subscriptions
                    </strong>
                </div>

                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Subscription Type</th>
                                <th>Subscription Status</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php if($sub->newspaper): ?> <?php echo e($sub->newspaper->title); ?> <?php elseif($sub->qualification): ?> <?php echo e($sub->qualification->title); ?> <?php else: ?> <?php echo e($sub->category->title); ?> <?php endif; ?></td>
                                <td><?php if($sub->newspaper): ?> <a href="<?php echo e(url('user-unscribe-news/'.$sub->newspaper->id)); ?>">unsubscribe</a> <?php elseif($sub->qualification): ?> <a href="<?php echo e(url('user-unscribe-qual/'.$sub->qualification->id)); ?>">unsubscribe</a> <?php else: ?> <a href="<?php echo e(url('user-unscribe-category/'.$sub->category->id)); ?>">unsubscribe</a> <?php endif; ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div><!--card body-->
            </div><!-- card -->
        </div><!-- col-xs-12 -->
    </div><!-- row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>