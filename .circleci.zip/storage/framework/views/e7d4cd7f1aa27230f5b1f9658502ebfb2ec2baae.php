

Adds Management


<?php $__env->startSection('breidcrumb'); ?>
<ol class="breadcrumb">
        <li class="breadcrumb-item">Home</li>

                                    <li class="breadcrumb-item"><a href="http://localhost:8000/admin/dashboard">Dashboard</a></li>
                                                <li class="breadcrumb-item active">Adds Management</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="form-horizontal" action="<?php echo e(route('admin.adds.update' , $add->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-5">
                        <h4 class="card-title mb-0">
                            Adds Management
                            <small class="text-muted">Adds Create</small>
                        </h4>
                    </div><!--col-->
                </div><!--row-->

                <hr>

                <div class="row mt-4 mb-4">
                    <div class="col">
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Adds Title</label>

                            <div class="col-md-10">
                                <input type="text" name="adds_title" class="form-control" placeholder="Enter Adds" value="<?php echo e($add->title); ?>">
                            </div><!--col-->
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Newspaper</label>

                            <div class="col-md-10">
                                <select name="newspaper_id" class="form-control">
                                    <option>Select NewsPaper</option>
                                    <?php $__currentLoopData = $newspaper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($data->id == $add->newspaper_id): ?> selected <?php endif; ?> value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div><!--col-->
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Qualifications</label>

                            <div class="col-md-10">
                                <select name="qualification_id" class="form-control">
                                    <option>Select Qualification</option>
                                    <?php $__currentLoopData = $qualification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($data->id == $add->qualification_id): ?> selected <?php endif; ?> value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div><!--col-->
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">City</label>

                            <div class="col-md-10">
                                <select name="city_id" class="form-control">
                                    <option value="null">Select City</option>
                                    <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($data->id == $add->city_id): ?> selected <?php endif; ?> value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div><!--col-->
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Category</label>

                            <div class="col-md-10">
                                <select name="category_id" class="form-control">
                                    <option>Select Category</option>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($data->id == $add->category_id): ?> selected <?php endif; ?> value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div><!--col-->
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Job Type</label>

                            <div class="col-md-10">
                                <select name="job_type_id" class="form-control">
                                    <option>Select Job Type</option>
                                    <?php $__currentLoopData = $jobType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($data->id == $add->job_type_id): ?> selected <?php endif; ?> value="<?php echo e($data->id); ?>"><?php echo e($data->job_type_title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div><!--col-->
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Add Type</label>

                            <div class="col-md-10">
                                <select name="add_types" class="form-control">
                                    <option value="jobs">Select Add Type</option>
                                    <option <?php if("jobs" == $add->type): ?> selected <?php endif; ?> value="jobs">Jobs</option>
                                    <option <?php if("tenders" == $add->type): ?> selected <?php endif; ?> value="tenders">Tendars</option>
                                    <option <?php if("admissions" == $add->type): ?> selected <?php endif; ?> value="admissions">Addmissions</option>
                                </select>
                            </div><!--col-->
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Total Positions</label>
                            <div class="col-md-10">
                            <input type="text" name="total_pos" class="form-control" placeholder="Total Positions" value="<?php echo e($add->total_pos); ?>">
                            </div>
                            
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Company Name</label>
                            <div class="col-md-10">
                            <input type="text" name="company_name" class="form-control" placeholder="Company Name" value="<?php echo e($add->company_name); ?>">
                            </div>
                            
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Company Abbrevation</label>
                            <div class="col-md-10">
                            <input type="text" name="company_abbrevation" class="form-control" placeholder="Company Abbrevation" value="<?php echo e($add->company_abbrevation); ?>">
                            </div>
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Job Location</label>
                            <div class="col-md-10">
                            <input type="text" name="job_loc" class="form-control" placeholder="Job Location" value="<?php echo e($add->job_loc); ?>">
                            </div>
                        </div><!--form-group-->
                         <div class="form-group row">
                            <label class="col-md-2 form-control-label">Gendar</label>
                            <div class="col-md-10">
                            <input type="text" name="gendar" class="form-control" placeholder="Gendar" value="<?php echo e($add->gender); ?>">
                            </div>
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Salary</label>
                            <div class="col-md-10">
                            <input type="text" name="salary" class="form-control" placeholder="Salary" value="<?php echo e($add->salary); ?>">
                            </div>
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Experience</label>
                            <div class="col-md-10">
                            <input type="text" name="experience" class="form-control" placeholder="Experience" value="<?php echo e($add->experience); ?>">
                            </div>
                        </div><!--form-group-->
                         <div class="form-group row">
                            <label class="col-md-2 form-control-label">Age Limit</label>
                            <div class="col-md-10">
                            <input type="text" name="age_limit" class="form-control" placeholder="Age Limit" value="<?php echo e($add->age_limit); ?>">
                            </div>
                        </div><!--form-group-->
                         <div class="form-group row">
                            <label class="col-md-2 form-control-label">Working Hours</label>
                            <div class="col-md-10">
                            <input type="text" name="work_hours" class="form-control" placeholder="Working hours" value="<?php echo e($add->working_hours); ?>">
                            </div>
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Skills</label>
                            <div class="col-md-10">
                            <input type="text" name="skills" class="form-control" placeholder="skills" value="<?php echo e($add->skills); ?>">
                            </div>
                        </div><!--form-group-->
                         <div class="form-group row">
                            <label class="col-md-2 form-control-label">Contact Number</label>
                            <div class="col-md-10">
                            <input type="text" name="contact_num" class="form-control" placeholder="Contact Number" value="<?php echo e($add->contact_number); ?>">
                            </div>
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Job Address</label>
                            <div class="col-md-10">
                            <input type="text" name="job_address" class="form-control" placeholder="Job Address" value="<?php echo e($add->address); ?>">
                            </div>
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Contact Email</label>
                            <div class="col-md-10">
                            <input type="text" name="contact_email" class="form-control" placeholder="Contact Email" value="<?php echo e($add->job_email); ?>">
                            </div>
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Minimum Requirements</label>

                            <div class="col-md-10">
                                <input type="text" name="min_req" class="form-control" placeholder="Enter Requirements" value="<?php echo e($add->minimum_requirements); ?>">
                            </div><!--col-->
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Description</label>

                            <div class="col-md-10">
                                <textarea name="description"><?php echo e($add->description); ?></textarea>
                            </div><!--col-->
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Apply By Date</label>

                            <div class="col-md-10">
                                <input type="date" name="apply_by" class="form-control" value="<?php echo e($add->apply_by); ?>">
                            </div><!--col-->
                        </div><!--form-group-->
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Last Date</label>

                            <div class="col-md-10">
                                <input type="date" name="last_date" class="form-control" value="<?php echo e($add->last_date); ?>">
                            </div><!--col-->
                        </div>
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Newspaper Piece</label>

                            <div class="col-md-10">
                                <input type="file" name="newspaper_piece" class="form-control" placeholder="Enter launch Date">
                            </div><!--col-->
                        </div>
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">Relevent Logo</label>

                            <div class="col-md-10">
                                <input type="file" name="rel_logo" class="form-control" placeholder="Enter launch Date">
                            </div><!--col-->
                        </div><!--form-group-->

                       


                       

                      



                    </div><!--col-->
                </div><!--row-->
            </div><!--card-body-->

            <div class="card-footer clearfix">
                <div class="row">
                    <div class="col">
                        <a class="btn btn-danger btn-sm" href="<?php echo e(url('/')); ?>">Cancel</a>
                    </div><!--col-->

                    <div class="col text-right">
                        <button class="btn btn-success btn-sm pull-right" type="submit">Create</button>
                    </div><!--col-->
                </div><!--row-->
            </div><!--card-footer-->
        </div><!--card-->
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>