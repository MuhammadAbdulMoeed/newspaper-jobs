

<?php $__env->startSection('title', app_name() . ' | ' . __('navs.frontend.dashboard') ); ?>

<?php $__env->startSection('content'); ?>

    <div class="row mb-8">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <strong>
                        <i class="fas fa-tachometer-alt"></i> <?php echo e(app('translator')->getFromJson('navs.frontend.dashboard')); ?>
                    </strong>
                </div><!--card-header-->

                <div class="card-body">
                    <div class="row">
                        <div class="col col-sm-4 order-1 order-sm-2  mb-4">
                            <div class="card mb-4 bg-light">

                                <div class="card-body">
                                    <h4 class="card-title">
                                        <?php echo e($logged_in_user->name); ?><br/>
                                    </h4>

                                    <p class="card-text">
                                        <small>
                                            <i class="fas fa-envelope"></i> <?php echo e($logged_in_user->email); ?><br/>
                                            <i class="fas fa-calendar-check"></i> <?php echo e(app('translator')->getFromJson('strings.frontend.general.joined')); ?> <?php echo e(timezone()->convertToLocal($logged_in_user->created_at, 'F jS, Y')); ?>

                                        </small>
                                    </p>

                                    <p class="card-text">

                                        <a href="<?php echo e(route('frontend.user.account')); ?>" class="btn btn-info btn-sm mb-1">
                                            <i class="fas fa-user-circle"></i> <?php echo e(app('translator')->getFromJson('navs.frontend.user.account')); ?>
                                        </a>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view backend')): ?>
                                            &nbsp;<a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-danger btn-sm mb-1">
                                                <i class="fas fa-user-secret"></i> <?php echo e(app('translator')->getFromJson('navs.frontend.user.administration')); ?>
                                            </a>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>

                        </div><!--col-md-4-->

                     
                    </div><!-- row -->
                </div> <!-- card-body -->
            </div><!-- card -->
            <br>
            <div class="card">
                <div class="card-header">
                    <strong>
                        <i class="fas fa-tachometer-alt"></i> Applied Jobs
                    </strong>
                </div><!--card-header-->

                <div class="card-body">
                    <div class="row">
                       <table class="table">
                           <thead>
                               <tr>
                                   <th>Sr.No</th>
                                   <th>Job Title</th>
                                   <th>Applied Date</th>
                                   <th>Status</th>
                               </tr>
                           </thead>
                           <tbody>
                               <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr>
                                   <td><?php echo e($job->id); ?></td>
                                   <td><?php echo e($job->getAdds->title); ?></td>
                                   <td><?php echo e($job->created_at); ?></td>
                                   <td><?php echo e($job->status); ?></td>
                               </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tbody>
                       </table>

                     
                    </div><!-- row -->
                </div> <!-- card-body -->
            </div><!-- card -->
        </div><!-- row -->
    </div><!-- row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>