<?php
$cat = App\Category::where('status' , '1')->get();
?>
<link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml" lang="en">

   <link rel="canonical" href="index.html">
   <!-- Mirrored from paperpk.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 13 Sep 2018 02:20:01 GMT -->
   <!-- Added by HTTrack -->
   <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
   <!-- /Added by HTTrack -->
   <head>
   <title><?php echo $__env->yieldContent('title', app_name()); ?></title>
      <meta http-equiv="Content-Type" content="text/html; charset=BIG5">
      <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <link rel="stylesheet" href="<?php echo e(asset('css/includes/bootstrap.min.css')); ?>" />
      <script src="<?php echo e(asset('js/includes/jquery.min.js')); ?>"></script>
      <script src="<?php echo e(asset('js/includes/bootstrap.min.js')); ?>"></script>
      <link rel="stylesheet" href="<?php echo e(asset('css/includes/my_style.css')); ?>" />
      <link rel="shortcut icon" href="images/favicon.ico" />
       <link rel="stylesheet" href="<?php echo e(asset('public/css/includes/fullcalendar.min.css')); ?>" />
       <link rel="stylesheet" href="<?php echo e(asset('public/css/slider/thumbnail-slider.css')); ?>" />
       <link rel="stylesheet" href="<?php echo e(asset('public/css/slider/thumbs2.css')); ?>" />
       <script src="<?php echo e(asset('public/css/slider/thumbnail-slider.js')); ?>"></script>
       <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.min.css">
 
      <style>
         #job-table table a:visited{background-color: black;}
         #company-img2 a:hover img{
         -webkit-filter: grayscale(100%) brightness(50);
         -moz-filter: grayscale(100%) brightness(50);
         }
         #company-img2 a:hover{
         color:white;
         } 
         .Newspaper_border a img:hover{
         border:1px dashed brown;
         }
         .Newspaper_border {
         padding-top:5px;
         border-right: #DBE1E6 1px solid;
         border-bottom: #DBE1E6 1px solid;
         }
         #table td{
         text-align:center;
         }
         #table img{
         width:75px;
         height: 40px;
         }
         #job-link{color:#F60;}
         a#job-link:visited{color: blue;}
         #admission-link{color:#C00;}
         #tender-link{color:#666;}
         #newspaper img{
         width: 90px; height: 40px;
         }
         #s-h{display:none;}
         a#job-one-lnkl:visited{color: gray;}
         a#company_sub_link{
         color: #cb65dc;
         font-size:0.8em;
         } 
      </style>
      
      <link rel="stylesheet" href="<?php echo e(asset('css/includes/my_style.css')); ?>" />
      <?php echo $__env->yieldPushContent('before-styles'); ?>

        <!-- Check if the language is set to RTL, so apply the RTL layouts -->
        <!-- Otherwise apply the normal LTR layouts -->
        <?php echo e(style(mix('css/frontend.css'))); ?>


        <?php echo $__env->yieldPushContent('after-styles'); ?>
   </head>
   <body>
      <div id="wrapper">
         <div id="main_container_mobile">
                <img alt="JobyLogo" src="pk_img/test.jpg" align="left" width="180px">
                <a id="nav_buttonid"><img alt="navigate-button" src="<?php echo e(asset('public/nav_head_logo.png')); ?>" align="right" width="45px" style="margin:7px 14px ;"></a>
                
                    <ul id="toggle_ul">
                        <?php if(auth()->user()): ?>
                  <a href="<?php echo e(url('/account')); ?>">My Account</a>
                  <?php else: ?>
                  <a href="<?php echo e(url('/register')); ?>">Job Seeker</a>
                  <br>
                  <a href="<?php echo e(url('/login')); ?>">Log in</a>
                  <?php endif; ?>
                    </ul>
            </div>
         <div id="main_container">
            <div id="menu_div">
               <div id="account_link">
                <?php if(auth()->user()): ?>
                  <a href="<?php echo e(url('/account')); ?>">My Account</a>
                  <?php else: ?>
                  <a href="<?php echo e(url('/register')); ?>">Job Seeker</a><a href="<?php echo e(url('/es-register')); ?>">Employer</a>
                  <a href="<?php echo e(url('/login')); ?>">Login</a>
                  <?php endif; ?>
               </div>
               <ul>
                  <li><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('public/home.png')); ?>" height=30px /></a></li>
                  <?php if($cat): ?>
                  <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><a href="<?php echo e(url('category/'.$ca->id)); ?>"><?php echo e($ca->title); ?></a></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
               </ul>
            </div>
         </div>
            <div id="logo_div">
            </div>
         <div id=clear></div>
         <?php echo $__env->yieldContent('content'); ?>
         
         <div id=footer>
            
            <img alt="Pk_banner" src="<?php echo e(asset('public/E31C2C11-C3B3-4560-A973-3B1461832C4E.jpg')); ?>" style="width:100%;" />
            <div id="copy-right">
               <table bgcolor="white" width="100%">
                  <tr>
                     <td bgcolor="white">
                        <p>  
                           CopyRight & Copy; 2018 & Trademark Test.Com Pvt Ltd.
                        </p>
                     </td>
                  </tr>
               </table>
               <br/> 
            </div>
            <br/>  <br/>       
            <script>
               function Hdiv(){
               document.getElementById("app").style.display="none";
               }
            </script>
         </div>
      </div>
      <?php echo $__env->yieldPushContent('before-scripts'); ?>
        <?php echo script(mix('js/manifest.js')); ?>

        <?php echo script(mix('js/vendor.js')); ?>

        <?php echo script(mix('js/frontend.js')); ?>

        <?php echo $__env->yieldPushContent('after-scripts'); ?>

   </body>
   <head>
      <script src="<?php echo e(asset('js/includes/my_js.js')); ?>"></script>
      <script src="<?php echo e(asset('js/includes/moment.min.js')); ?>"></script>
      <script src="<?php echo e(asset('js/includes/fullcalendar.min.js')); ?>"></script>
      <script src="<?php echo e(url('js/includes/jquery.validate.js')); ?>"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js"></script>
      <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/moment@2.22.2/moment.min.js"></script>

      <?php echo $__env->yieldContent('js-script'); ?>
      <script>

         $(document).ready(function(){

var url1 = "<?php echo e(url('showcalenderjobs')); ?>"
var url2 = "<?php echo e(url('showcalendertender')); ?>"
var url3 = "<?php echo e(url('showcalenderadmissions')); ?>"
            function search(){
               var news = $('#newspaper').find(":selected").text();
               var type = $('#job_type').find(":selected").text();
               var date = $('#date').val();
               windows.location = "<?php echo e(url('/')); ?>"+news+"/"+type+"/"+date

            }
         
            $('#calendar2').fullCalendar({
              header: {
        left: '',
        center: '',
        right: ''
    },
              dayClick: function(date, jsEvent, view) {
    window.location = "<?php echo e(url('apply_date/')); ?>"+'/'+date.format()

  }
            });
             $("#m-btn").click(function(){
                 $("#s-h").toggle('slow');
         
             });
             $('#calendar3').fullCalendar({
               header: {
        left: 'prev,next today',
        center: 'title',
        right: 'month,agendaWeek,agendaDay'
    },
   eventSources: [
    url1,
    url2,
    url3
  ],
  eventClick: function (calEvent, jsEvent, view) {
    console.log('html' , calEvent)
    window.location = calEvent.html;
},
});
         
         });
         
      </script>
      <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-124198877-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-124198877-2');
</script>
   </head>
</html>