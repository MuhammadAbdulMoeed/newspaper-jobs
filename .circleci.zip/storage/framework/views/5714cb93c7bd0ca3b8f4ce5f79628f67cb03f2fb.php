<?php
$adsense = App\AdsenseCode::where('size' , '764x267')->inRandomOrder()->first();
?>
<?php if(!empty($adsense)): ?>
<?php echo $adsense->code; ?>

<?php else: ?>
<img src="<?php echo e(asset('img/download.jpg')); ?>" style="width: 764px; max-height: 267px;"></tr>
<?php endif; ?>