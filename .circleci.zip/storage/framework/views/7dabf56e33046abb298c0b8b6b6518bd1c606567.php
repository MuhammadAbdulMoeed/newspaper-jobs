<?php
$path = 'frontend.includes.'.$data;
           ?>
           <?php if(isset($viewonly)): ?>
           <?php echo $__env->make($path, \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           <?php else: ?>
           <tr><td colspan="4">
<center id="ad_r">
<?php echo $__env->make($path, \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</center>
</td></tr>
           <?php endif; ?>
           