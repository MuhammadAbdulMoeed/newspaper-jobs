<footer class="app-footer">
    <div>
        <strong><?php echo e(app('translator')->getFromJson('labels.general.copyright')); ?> &copy; <?php echo e(date('Y')); ?> <a href="http://laravel-boilerplate.com"><?php echo e(app('translator')->getFromJson('strings.backend.general.boilerplate_link')); ?></a></strong> <?php echo e(app('translator')->getFromJson('strings.backend.general.all_rights_reserved')); ?>
    </div>

    <div class="ml-auto">Powered by <a href="http://coreui.io">CoreUI</a></div>
</footer>
