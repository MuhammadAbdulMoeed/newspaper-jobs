<?php
$adsense = App\AdsenseCode::where('size' , '700x90')->inRandomOrder()->first();
?>
<?php if(!empty($adsense)): ?>
<?php echo $adsense->code; ?>

<?php else: ?>
<img src="<?php echo e(asset('img/download.jpg')); ?>" style="width: 700px; max-height: 90px;"></tr>
<?php endif; ?>