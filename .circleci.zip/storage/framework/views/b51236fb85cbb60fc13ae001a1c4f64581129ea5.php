

Cities Management


<?php $__env->startSection('breidcrumb'); ?>
<ol class="breadcrumb">
        <li class="breadcrumb-item">Home</li>

                                    <li class="breadcrumb-item"><a href="http://localhost:8000/admin/dashboard">Dashboard</a></li>
                                                <li class="breadcrumb-item active">User Management</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="form-horizontal" action="<?php echo e(route('admin.cities.update' , $city->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-5">
                        <h4 class="card-title mb-0">
                            Cities Management
                            <small class="text-muted">Cities Create</small>
                        </h4>
                    </div><!--col-->
                </div><!--row-->

                <hr>

                <div class="row mt-4 mb-4">
                    <div class="col">
                        <div class="form-group row">
                            <label class="col-md-2 form-control-label">City Title</label>

                            <div class="col-md-10">
                                <input type="text" name="city_title" class="form-control" placeholder="Enter City" value="<?php echo e($city->title); ?>">
                            </div><!--col-->
                        </div><!--form-group-->


                       


                       

                      



                    </div><!--col-->
                </div><!--row-->
                 <div class="form-group row">
                            <label class="col-md-2 form-control-label">City Logo</label>

                            <div class="col-md-10">
                                <input type="file" name="logo" class="form-control" placeholder="Enter launch Date">
                            </div><!--col-->
                        </div>
            </div><!--card-body-->

            <div class="card-footer clearfix">
                <div class="row">
                    <div class="col">
                        <a class="btn btn-danger btn-sm" href="<?php echo e(url('/')); ?>">Cancel</a>
                    </div><!--col-->

                    <div class="col text-right">
                        <button class="btn btn-success btn-sm pull-right" type="submit">Update</button>
                    </div><!--col-->
                </div><!--row-->
            </div><!--card-footer-->
        </div><!--card-->
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>