<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomMessagee extends Model
{
    protected $table = "custom_message";
}
